/*
 * sensor.h
 *
 *      Author: Yudha Birawa Nuraga
 *      E-mail: yudhabhirdokter@gmail.com
 */

#ifndef SENSOR_H_
#define SENSOR_H_

#include "stm32f1xx_hal.h"

uint8_t sensorDetected(void);
uint8_t Sensor_1(void);
uint8_t Sensor_2(void);
uint8_t Sensor_3(void);


#endif /* SENSOR_H_ */
