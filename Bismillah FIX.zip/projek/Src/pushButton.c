/*
 * pushButton.c
 *
 *      Author: Yudha Birawa Nuraga
 *      E-mail: yudhabhirdokter@gmail.com
 */
#include "pushButton.h"
#include "main.h"
#include "stdint.h"

extern unsigned char debugMode;

uint8_t startStopDetected(void){
	uint32_t  Timeout_loop=0;
	uint32_t  Timeout_value=0x100000;
	uint32_t  indeks_delay=50;
	uint8_t FlagDetect=0;
	if(HAL_GPIO_ReadPin(pbStartStop_GPIO_Port,pbStartStop_Pin)==GPIO_PIN_RESET) {
		HAL_Delay(20);
		if(HAL_GPIO_ReadPin(pbStartStop_GPIO_Port,pbStartStop_Pin)==GPIO_PIN_RESET) {
			while((HAL_GPIO_ReadPin(pbStartStop_GPIO_Port,pbStartStop_Pin)==GPIO_PIN_RESET) && (Timeout_loop++<=Timeout_value));
				if (Timeout_loop>=Timeout_value){
						if(debugMode==0){
								while(--indeks_delay){
									LCD_Gotoxy(0,0);
									LCD_Puts(" MODE DEBUGING ");
									debugMode=1;
								}
							}else{
								while(--indeks_delay){
									LCD_Gotoxy(0,0);
									LCD_Puts("  MODE NORMAL  ");
									debugMode=0;
								}
							}
				} else{
					FlagDetect=1;
				}
		}
	}
	return FlagDetect;
}
uint8_t resetDetected(void){
	uint32_t  Timeout_loop=0;
	uint32_t  Timeout_value=0x100000;
	uint32_t  indeks_delay=50;
	uint8_t FlagDetect=0;
	if(HAL_GPIO_ReadPin(pbReset_GPIO_Port,pbReset_Pin)==GPIO_PIN_RESET) {
		HAL_Delay(10);
		if(HAL_GPIO_ReadPin(pbReset_GPIO_Port,pbReset_Pin)==GPIO_PIN_RESET) {
			while((HAL_GPIO_ReadPin(pbReset_GPIO_Port,pbReset_Pin)==GPIO_PIN_RESET) && (Timeout_loop++<=Timeout_value));
				if (Timeout_loop>=Timeout_value){
					while(indeks_delay--){
						sprintf(buff, "Button Reset Error! \n");
						LCD_Gotoxy(0,0);
						LCD_Puts("PbReset Error! ");
						Serial_print(buff);
					}
				} else{
					FlagDetect=1;
				}
		}
	}
	return FlagDetect;
}


