/*
 * sensor.c
 *
 *  Created on: 19 Nov 2017
 *      Author: Yudha Birawa Nuraga
 *      E-mail: yudhabhirdokter@gmail.com
 */
#include "sensor.h"
#include "main.h"
#include "stdint.h"
#include "lcd16x2.h"

uint8_t sensorDetected(void){
	uint32_t  Timeout_loop=0;
	uint32_t  Timeout_value=0x100000;
	uint32_t  indeks_delay=50;
	uint8_t FlagDetect=0;
	if(HAL_GPIO_ReadPin(sensor_GPIO_Port,sensor_Pin)==GPIO_PIN_RESET) {
		HAL_Delay(10);
		if(HAL_GPIO_ReadPin(sensor_GPIO_Port,sensor_Pin)==GPIO_PIN_RESET) {
			while((HAL_GPIO_ReadPin(sensor_GPIO_Port,sensor_Pin)==GPIO_PIN_RESET) && (Timeout_loop++<=Timeout_value));
			if (Timeout_loop>=Timeout_value){
					while(indeks_delay--){
						LCD_Gotoxy(0,0);
						LCD_Puts("Sensor Error! ");
					}
				} else{
					FlagDetect=1;
				}
		}
	}
	return FlagDetect;
}
uint8_t Sensor_1(void){
	uint32_t  Timeout_loop=0;
	uint32_t  Timeout_value=0x100000;
	uint32_t  indeks_delay=50;
	uint8_t FlagDetect=0;
	if(HAL_GPIO_ReadPin(sensor1_GPIO_Port,sensor1_Pin)==GPIO_PIN_RESET) {
		HAL_Delay(10);
		if(HAL_GPIO_ReadPin(sensor1_GPIO_Port,sensor1_Pin)==GPIO_PIN_RESET) {
			while((HAL_GPIO_ReadPin(sensor1_GPIO_Port,sensor1_Pin)==GPIO_PIN_RESET) && (Timeout_loop++<=Timeout_value));
				if (Timeout_loop>=Timeout_value){
					while(indeks_delay--){
						sprintf(buff, "Sensor1 Error! \n");
						LCD_Gotoxy(0,0);
						LCD_Puts("Sensor1 Error! ");
						Serial_print(buff);
					}
				} else{
					FlagDetect=1;
				}
		}
	}
	return FlagDetect;
}

uint8_t Sensor_2(void){
	uint32_t  Timeout_loop=0;
	uint32_t  Timeout_value=0x100000;
	uint32_t  indeks_delay=50;
	uint8_t FlagDetect=0;
	if(HAL_GPIO_ReadPin(sensor2_GPIO_Port,sensor2_Pin)==GPIO_PIN_RESET) {
		HAL_Delay(10);
		if(HAL_GPIO_ReadPin(sensor2_GPIO_Port,sensor2_Pin)==GPIO_PIN_RESET) {
			while((HAL_GPIO_ReadPin(sensor2_GPIO_Port,sensor2_Pin)==GPIO_PIN_RESET) && (Timeout_loop++<=Timeout_value));
				if (Timeout_loop>=Timeout_value){
					while(indeks_delay--){
						sprintf(buff, "Sensor2 Error! \n");
						LCD_Gotoxy(0,0);
						LCD_Puts("Sensor2 Error! ");
						Serial_print(buff);
					}
				} else{
					FlagDetect=1;
				}
		}
	}
	return FlagDetect;
}
uint8_t Sensor_3(void){
	uint32_t  Timeout_loop=0;
	uint32_t  Timeout_value=0x100000;
	uint32_t  indeks_delay=50;
	uint8_t FlagDetect=0;
	if(HAL_GPIO_ReadPin(sensor3_GPIO_Port,sensor3_Pin)==GPIO_PIN_RESET) {
		HAL_Delay(10);
		if(HAL_GPIO_ReadPin(sensor3_GPIO_Port,sensor3_Pin)==GPIO_PIN_RESET) {
			while((HAL_GPIO_ReadPin(sensor3_GPIO_Port,sensor3_Pin)==GPIO_PIN_RESET) && (Timeout_loop++<=Timeout_value));
				if (Timeout_loop>=Timeout_value){
					while(indeks_delay--){
						sprintf(buff, "Sensor3 Error! \n");
						LCD_Gotoxy(0,0);
						LCD_Puts("Sensor3 Error! ");
						Serial_print(buff);
					}
				} else{
					FlagDetect=1;
				}
		}
	}
	return FlagDetect;
}


